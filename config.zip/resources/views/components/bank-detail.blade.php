<div>
    <div class="warning-box">
        <p>A non refundable deposit (alternatively you can pay full amount) of 20% of the total trip
            amount will be charged whilst booking your trip and the rest will be paid up on your
            arrival in Kathmandu. For this deposit can be made by Bank wire transfer or by credit
            card (not online due to security measure), and each process has been described as given
            below.</p>
    </div>
    <div class="warning-box">
        <h4>Payment by wire transfer</h4>
        <p>Beneficiary Bank: Nabil Bank Ltd. <br>
            Beneficiary Company: Nepal Vision Treks & Expedition (P). Ltd. <br>
            Account No. : 0102211820301 <br>
            Account Type : Current Account</p>


        <h5>Bank Address</h5>
        <p> Nabil House, Kamaladi, Kathmandu <br>
            P.O. Box: 3729, Kathmandu <br>
            SWIFT: NARBNPKA <br>
            Web Address: www.nabilbank.com</p>


        <p>Beneficiary Bank:- Himalayan Bank Ltd. <br>
            Beneficiary Company:- Nepal Vision Treks & Expedition (P). Ltd. <br>
            Account No. :- 01900041700038 <br>
            Account Type :- Current Account</p>

        <h5>Bank Address</h5>
        <p>Sanchaya Kosh Building, Tridevimarga <br>
            P.O. Box: 20590, Thamel, Kathmandu <br>
            SWIFT: HIMANPKA <br>
            Web Address: www.himalayanbank.com</p>
    </div>
</div>