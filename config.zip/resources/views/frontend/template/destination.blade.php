


<section class="best-place-destination mt-5">
    <div class="container">
        <div class="heading ">
            <p class="custom-fs-36">
                Top Destination
            </p>
        </div>
      
    </div>
</section>