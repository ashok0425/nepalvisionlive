<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PackageFeatrured extends Model
{
    protected $table="package_featured";
}
