<section class="partners py-5">
    <div class="container">
        <div class="heading mt-2 mb-5">
            <p class="custom-fs-36 text-center">Our Affiliations</p>
        </div>
        <div class="owl-carousel afflicated">
            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>

            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webpaffiliation2.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>

            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webpaffiliation3.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>


            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webpaffiliation4.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>


            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webpaffiliation5.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>


            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webpaffiliation6.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>


            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webpaffiliation7.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>

            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webpaffiliation8.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>

            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webpaffiliation9.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>


            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webpaffiliation1.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>


            <div>
                <img data-src="{{ getImageurl('public/aff/affiliation1.webpaffiliation10.webp') }}" alt="affiliated"
                    class="img-fluid lazy w-50" width="100" height="100">
            </div>




        </div>
    </div>
</section>
