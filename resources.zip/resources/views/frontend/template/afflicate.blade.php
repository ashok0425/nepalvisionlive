<section class="partners py-5">
    <div class="container">
        <div class="heading mt-2 mb-5">
            <h2>Our Affiliations</h2>
        </div>
        <div class="owl-carousel afflicated">
            <div >
                <img src="{{ asset('aff/affiliation1.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>

            <div >
                <img src="{{ asset('aff/affiliation2.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>

            <div >
                <img src="{{ asset('aff/affiliation3.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>


            <div >
                <img src="{{ asset('aff/affiliation4.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>


            <div >
                <img src="{{ asset('aff/affiliation5.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>


            <div >
                <img src="{{ asset('aff/affiliation6.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>


            <div >
                <img src="{{ asset('aff/affiliation7.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>

            <div >
                <img src="{{ asset('aff/affiliation8.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>

            <div >
                <img src="{{ asset('aff/affiliation9.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>


            <div >
                <img src="{{ asset('aff/affiliation1.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>


            <div >
                <img src="{{ asset('aff/affiliation10.jpg') }}" alt="affiliated" class="img-fluid w-50" x>
            </div>


           
            
        </div>
    </div>
</section>