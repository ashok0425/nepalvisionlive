<section class="partners py-5">
    <div class="container">
        <div class="heading mt-2 mb-5">
            <h2>Our Affiliations</h2>
        </div>
        <div class="owl-carousel afflicated">
            <div >
                <img data-src="{{ asset('aff/affiliation1.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>

            <div >
                <img data-src="{{ asset('aff/affiliation2.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>

            <div >
                <img data-src="{{ asset('aff/affiliation3.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>


            <div >
                <img data-src="{{ asset('aff/affiliation4.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>


            <div >
                <img data-src="{{ asset('aff/affiliation5.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>


            <div >
                <img data-src="{{ asset('aff/affiliation6.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>


            <div >
                <img data-src="{{ asset('aff/affiliation7.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>

            <div >
                <img data-src="{{ asset('aff/affiliation8.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>

            <div >
                <img data-src="{{ asset('aff/affiliation9.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>


            <div >
                <img data-src="{{ asset('aff/affiliation1.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>


            <div >
                <img data-src="{{ asset('aff/affiliation10.webp') }}" alt="affiliated" class="img-fluid lazy w-50" width="100" height="100" >
            </div>


           
            
        </div>
    </div>
</section>