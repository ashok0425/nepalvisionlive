<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AllImage extends Model
{
	protected $table="destination_image";
    //
}
