


<section class="best-place-destination mt-5">
    <div class="container">
        <div class="heading ">
            <h2>
                Top Destination
            </h2>
        </div>
      
    </div>
</section>