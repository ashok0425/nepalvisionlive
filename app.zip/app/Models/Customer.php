<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
	protected $table ="customer";
 //    protected $fillable=['title','f_name','l_name','mailing_address','email','country','occupation','phone_day','phone_evening','passport_no','passport_place_issue','expiry_date','emergency_contact','booking','departure_date','no_traveller','insurance'];
 //    public function customer() {
	// 	return $this->hasMany('App\Models\Customer', 'booking_id');
	// }
}